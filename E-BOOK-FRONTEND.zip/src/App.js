import React, { useState } from "react";
import "./App.css";
import Home from "./components/Home";
import Admin from "./components/Admin";
import UpdateProfile from "./components/UpdateProfile";
import Catalog from "./components/Catalog";
import AddBook from "./components/AddBook";
import ViewBook from "./components/ViewBook";
import User from "./components/User";
import Login from "./components/Login";
import Read from "./components/Read";
import Register from "./components/Register";
import { BrowserRouter, Route, Router, Link, Routes } from "react-router-dom";

export default function App() {
  const [currentForm, setCurrentForm] = useState("Login");

  const toggleForm = (formName) => {
    setCurrentForm(formName);
  };

  return (
    <>
      {/* <div className="App">
        {currentForm === "Login" ? (
          <Login onFormSwitch={toggleForm} />
        ) : (
          <Register onFormSwitch={toggleForm} />
        )}
      </div> */}

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Catalog" element={<Catalog />} />
        <Route path="/AddBook" element={<AddBook />} />
        <Route path="/ViewBook" element={<ViewBook />} />
        <Route path="/UpdateProfile" element={<UpdateProfile />} />
        <Route path="/login" element={<Login />} />
        <Route path="/Admin" element={<Admin />} />
        <Route path="/User" element={<User />} />
        <Route path="/Read" element={<Read />} />
        <Route path="/Register" element={<Register />} />
      </Routes>
    </>
  );
}
