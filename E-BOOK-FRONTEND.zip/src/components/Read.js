import React, { useState, useEffect, useParams } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { CSVLink } from "react-csv";
import axios from "axios";
import { jsPDF } from "jspdf";


export default function Read(){

  //const doc = new jsPDF('p','pt','letter');

  const location = useLocation() ;
   const { book } = location.state;
   useEffect(() => {
    const filterData = (e) => {
      if (book!= "") {
        console.log(book);
        // setValue(e.target.value);
        const filterTable = dataSource.filter((o) =>
          Object.keys(o).some((k) =>
            String(o[k]).toLowerCase().includes(book.toLowerCase())
          )
        );
        setTableFilter([...filterTable]);
        console.log(filterTable);
      } else {
        setValue(e.target.value);
        setDataSource([...dataSource]);
      }
    };
    filterData();
}, []);


   console.log(book);
   const dummyData = [
    { BookName: "Friction", InsertedDate: "2003/04/21", AuthorName: "Mathew" },
    { BookName: "Earth", InsertedDate: "2005/01/12", AuthorName: "Joseph" },
    {
      BookName: "Larry The Bird",
      InsertedDate: "1999/04/19",
      AuthorName: "Harry"
    }
  ];

  //const boook="https://jx8989.csb.app/Read/book.pdf"

  const [results, setResults] = useState([]);
  const [value, setValue] = useState("");
  const [dataSource, setDataSource] = useState(dummyData);
  const [tableFilter, setTableFilter] = useState([]);
  const navigate = useNavigate();

  const backbutton = (e) => {
    e.preventDefault();
    navigate("/Catalog");
  };

  // const downloadFile=(url) =>{
  //   console.log(url);
  //   const BookName=url.BookName;
  //   const data={
  //     callback:function (doc) {
  //       doc.save("book.pdf");
        
  //     },
  //     margin:[10,10,10,10],
  //   }
  //    doc.html(BookName,data);
     

    // const fileName= "book.pdf"
    // console.log(fileName);
    // const aTag=document.createElement('a');
    // aTag.href=url;
    // aTag.setAttribute('download',fileName);
    // document.body.appendChild(aTag);
    // aTag.click();
    // aTag.remove();

  //}

  return(
    <>

   <div className="view-book">
        <div class="table">
          <br />
          <table>
            <thead>
              <tr>
                <th scope="col">Book Name</th>
                <th scope="col">Inserted Date</th>
                <th scope="col">Author Name</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {book.length > 0
                ? tableFilter.map((data) => {
                    return (
                      <tr>
                        <td>{data.BookName} </td>
                        <td>{data.InsertedDate} </td>
                        <td>{data.AuthorName} </td>
                        <td>
                        <CSVLink className="downloadbtn" filename="book.csv" data={tableFilter}>
        Download
      </CSVLink>
                        {/* <button
                         //onClick={() => {downloadFile(tableFilter)}}
                          //  to="/Read"
                            // href="dummyData"
                            // download="book.pdf"
                          //className="btn btn-success"
                           //state={{ book: data.BookName }}
                        > */}
                          {/* {" "} */}
                          {/* Download */}
                        {/* </button>*/}
                        </td> 
                        {/* <td><a
                           to="/Read"
                          href="Read.js"
                          download="book.pdf"
                          className="btn btn-success"
                           state={{ book: data.BookName }}
                        >
                          {" "}
                          Download
                        </a></td> */}
                      </tr>
                    );
                  })
                : dataSource.map((data) => {
                    return (
                      <tr>
                        <td>{data.BookName} </td>
                        <td>{data.InsertedDate} </td>
                        <td>{data.AuthorName} </td>
                        <td>
                          {/* <button
                        onClick={() => {downloadFile(tableFilter)}}
                          //  to="/Read"
                          //  href="book"
                          //  download="book.pdf"
                          className="btn btn-success"
                           //state={{ book: data.BookName }}
                        >
                          {" "}
                          Download
                        </button> */}
                        </td>
                        {/* <td><a
                           to="/Read"
                          href="book"
                          download="book.pdf"
                          className="btn btn-success"
                           state={{ book: data.BookName }}
                        >
                          {" "}
                          Download
                        </a></td> */}
                      </tr>
                    );
                  })}
            </tbody>
          </table>
        </div>
        <div className="viewbookcancel">
          <button type="cancel" onClick={backbutton}>
            Cancel
          </button>
        </div>
      </div>
    </>
  )

}