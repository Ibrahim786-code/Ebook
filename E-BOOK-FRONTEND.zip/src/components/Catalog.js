import { useNavigate } from "react-router-dom";
import React, { useState } from "react";
import { Link, BrowserRouter } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";

export default function ViewBook() {
  const dummyData = [
    { BookName: "Friction", InsertedDate: "2003/04/21", AuthorName: "Mathew" },
    { BookName: "Earth", InsertedDate: "2005/01/12", AuthorName: "Joseph" },
    {
      BookName: "Larry The Bird",
      InsertedDate: "1999/04/19",
      AuthorName: "Harry"
    }
  ];

  const [results, setResults] = useState([]);

  const [value, setValue] = useState("");
  const [dataSource, setDataSource] = useState(dummyData);
  const [tableFilter, setTableFilter] = useState([]);

  const filterData = (e) => {
    if (e.target.value != "") {
      setValue(e.target.value);
      const filterTable = dataSource.filter((o) =>
        Object.keys(o).some((k) =>
          String(o[k]).toLowerCase().includes(e.target.value.toLowerCase())
        )
      );
      setTableFilter([...filterTable]);
    } else {
      setValue(e.target.value);
      setDataSource([...dataSource]);
    }
  };

  const navigate = useNavigate();

  const backbutton = (e) => {
    e.preventDefault();
    navigate("/User");
  };

  return (
    <>
      <div className="catalog">
        <div className="catalog-search-bar-container">
          <input
            type="text"
            class="form-control"
            placeholder="Search"
            aria-label="BookName"
            aria-describedby="basic-addon1"
            value={value}
            onChange={filterData}
            // setResults={setResults}
          />
        </div>
        <div class="table">
          <br />
          <table>
            <thead>
              <tr>
                <th scope="col">Book Name</th>
                {/* <th scope="col">Inserted Date</th>
                <th scope="col">Author Name</th> */}
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {value.length > 0
                ? tableFilter.map((data) => {
                    return (
                      <tr>
                        <td>{data.BookName} </td>
                        {/* <td>{data.InsertedDate} </td>
                        <td>{data.AuthorName} </td> */}
                        {/* <Link
                          className="btn btn-sm btn-success"
                          to="/Read/data.BookName"
                        >
                          Read
                        </Link> */}
                        <Link
                          to="/Read"
                          className="btn btn-success"
                          state={{ book: data.BookName }}
                        >
                          {" "}
                          Read
                        </Link>
                      </tr>
                    );
                  })
                : dataSource.map((data) => {
                    return (
                      <tr>
                        <td>{data.BookName} </td>
                        {/* <td>{data.InsertedDate} </td>
                        <td>{data.AuthorName} </td> */}
                        <td>
                          {/* <Link
                            className="btn btn-sm btn-success"
                            to="/Read/data.BookName"
                          >
                            Read
                          </Link> */}
                          <Link
                            to="/Read"
                            className="btn btn-success"
                            state={{ book: data.BookName }}
                          >
                            {" "}
                            Read
                          </Link>
                        </td>
                      </tr>
                    );
                  })}
            </tbody>
          </table>
        </div>

        {/* <div className="results-list">
          {/* <div>a</div>
        <div>c</div>
        <div>b</div> */}
        {/* {results.map((result, id) => {
            return (
              <div
                className="search"
                key={id}
                onClick={(e) => alert(`You clicked on ${result.filterTable}`)}
              >
                {result.filterTable}
              </div> */}
        {/* );
          })}
        </div> */}

        <div className="viewbookcancel">
          <button type="cancel" onClick={backbutton}>
            Cancel
          </button>
        </div>
      </div>
    </>
  );
}
