import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

// const USER_REGEX = /^[a-zA-Z][a-zA-Z0-9-_]{3,23}$/;
// const PWD_REGX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%]).{8,24}$/;

const AddBook = (props) => {
  const [add, setAdd] = useState({
    cname: "",
    btitle: "",
    date: "",
    aname: ""
  });
  // const [error, setErrMsg] = useState("");
  const [records, setRecords] = useState([]);

  const handleInput = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    console.log(name, value);

    setAdd({ ...add, [name]: value });
  };
  const navigate = useNavigate();

  const backbutton = (e) => {
    e.preventDefault();
    navigate("/Admin");
  };
  // const gotologin = (e) => {
  //   e.preventDefault();
  //   navigate("/Login");
  // };

  const handleSubmit = (e) => {
    e.preventDefault();
    // if(records === 0){
    //   setErrMsg("Invalid email or password");
    // }
    // else{

    const newRecord = { ...add, id: new Date().getTime().toString() };
    console.log(records);
    setRecords([...records, newRecord]);
    console.log(records);

    setAdd({ cname: "", btitle: "", date: "", aname: "" });
  };

  return (
    <div className="add-book">
      <h2>Add Book</h2>
      <form className="add-book" onSubmit={handleSubmit}>
        <label htmlFor="cname">Catalog Name</label>
        <input
          value={add.cname}
          onChange={handleInput}
          // onChange={(e) => setFname(e.target.value)}
          autoComplete="off"
          name="cname"
          id="name"
          placeholder="Catalog Name"
        />
        <br />
        <label htmlFor="btitle">Book Title</label>
        <input
          value={add.btitle}
          // onChange={(e) => setLname(e.target.value)}
          onChange={handleInput}
          autoComplete="off"
          name="btitle"
          id="btitle"
          placeholder="Book Title"
        />
        <br />
        <label htmlFor="date">Inserted Date</label>
        <input
          type="date"
          value={add.date}
          onChange={handleInput}
          // onChange={(e) => setContact(e.target.value)}
          autoComplete="off"
          name="date"
          id="date"
          placeholder="date"
        />
        <br />
        <label htmlFor="aname">Author Name &nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input
          value={add.aname}
          onChange={handleInput}
          // onChange={(e) => setEmail(e.target.value)}
          autoComplete="off"
          type="aname"
          id="aname"
          name="aname"
          placeholder="Author Name"
        />
        <br />
        {/* {error && <p className="error">{error}</p>} */}
        <button type="submit" onClick={handleSubmit}>
          Add
        </button>
        &nbsp;&nbsp;&nbsp;
        <button type="cancel" onClick={backbutton}>
          Cancel
        </button>
      </form>
      <div>
        {records.map((curElem) => {
          const { id, cname, btitle, date, aname } = curElem;
          return (
            <div key={id}>
              <p>{cname}</p>
              <p>{btitle}</p>
              <p>{date}</p>
              <p>{aname}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AddBook;

//  {/* {register ? (
//                 <p >You Are Registered Successfully</p>
//             ) :  (
//                 <p >You Are Not Registered</p>
//             )} */}

// const userRef = useRef();
// const errRef = useRef();

// const [fname, setFname] = useState("");
// const [validFname, setValidFname] = useState(false);
// const [fnameFocus, setFnameFocus] = useState(false);

// const [lname, setLname] = useState("");
// const [validLname, setValidlName] = useState(false);
// const [lnameFocus, setLnameFocus] = useState(false);

// const [contact, setContact] = useState("");
// const [validContact, setValidContact] = useState(false);
// const [contactFocus, setContactFocus] = useState(false);

// const [email, setEmail] = useState("");
// const [validEmail, setValidEmail] = useState(false);
// const [emailFocus, setEmailFocus] = useState(false);

// const [pass, setPass] = useState("");
// const [validPass, setValidPass] = useState(false);
// const [passFocus, setPassFocus] = useState(false);

// const [matchPass, setMatchPass] = useState("");
// const [validMatch, setValidMatch] = useState(false);
// const [matchFocus, setMatchFocus] = useState(false);

// const [ errMsg, setErrMsg ] = useState('');
// const [success, setSuccess ] = useState(false);

// useEffect ( () => {
//   // userRef.current.focus();

// }, [])

// setRegister(true);

//   const configuration = {
//     method: "post",
//     // url: "https://nodejs-mongodb-auth-app-learn.herokuapp.com/register",
//     data: {
//       fname,
//       lname,
//       contact,
//       email,
//       pass,
//     },
// };
// axios(configuration)
//           .then((result) => {
//               console.log(result);
//               setRegister(true);
//           })
//           .catch((error) => {
//               error= new Error;
//           })

// console.log(email);

// {/* <label htmlFor="password">Re-enter Password </label>
//   <input
//     value={register.matchPass}
//     onChange={ handleInput }
//     // onChange={(e) => setMatchPass(e.target.value)}
//     autoComplete="off"
//      type="password"
//     id="password"
//      name="password"
//      placeholder="******"
//   /> */}
