import React, { useRef, useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  faCheck,
  faTimes,
  faInfoCircle
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import Login from './Login';

const USER_REGEX = /^[a-zA-Z][a-zA-Z0-9-_]{3,23}$/;
const PWD_REGX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%]).{8,24}$/;

const UpdateProfile = (props) => {
  const [update, setUpdate] = useState({
    fname: "",
    lname: "",
    contact: "",
    email: "",
    password: ""
  });
  const [error, setErrMsg] = useState("");
  const [records, setRecords] = useState([]);

  const handleInput = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    console.log(name, value);

    setUpdate({ ...update, [name]: value });
  };
  const navigate = useNavigate();

  const backbutton = (e) => {
    e.preventDefault();
    navigate("/User");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // if(records === 0){
    //   setErrMsg("Invalid email or password");
    // }
    // else{

    const newRecord = { ...update, id: new Date().getTime().toString() };
    console.log(records);
    setRecords([...records, newRecord]);
    console.log(records);

    setUpdate({ fname: "", lname: "", contact: "", email: "", password: "" });
  };

  return (
    <div className="update-form">
      <h2>Update Profile</h2>
      <form className="update-form" onSubmit={handleSubmit}>
        <label htmlFor="fname">First Name</label>
        <input
          value={update.fname}
          onChange={handleInput}
          // onChange={(e) => setFname(e.target.value)}
          autoComplete="off"
          name="fname"
          id="name"
          placeholder="First Name"
        />
        <br />
        <label htmlFor="lname">Last Name</label>
        <input
          value={update.lname}
          // onChange={(e) => setLname(e.target.value)}
          onChange={handleInput}
          autoComplete="off"
          name="lname"
          id="name"
          placeholder="Last Name"
        />
        <br />
        <label htmlFor="contact">Contact</label>
        <input
          type="text"
          value={update.contact}
          onChange={handleInput}
          // onChange={(e) => setContact(e.target.value)}
          autoComplete="off"
          name="contact"
          id="contact"
          placeholder="Contact"
        />
        <br />
        <label htmlFor="email">Email &nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input
          value={update.email}
          onChange={handleInput}
          // onChange={(e) => setEmail(e.target.value)}
          autoComplete="off"
          type="email"
          id="email"
          name="email"
          placeholder="abc@gmail"
        />
        <br />
        <label htmlFor="password">Password </label>
        <input
          value={update.password}
          onChange={handleInput}
          // onChange={(e) => setPass(e.target.value)}
          autoComplete="off"
          type="password"
          id="password"
          name="password"
          placeholder="******"
        />
        <br />
        {error && <p className="error">{error}</p>}
        <button type="submit" onClick={handleSubmit}>
          Update
        </button>
        &nbsp;&nbsp;&nbsp;
        <button type="cancel" onClick={backbutton}>
          Cancel
        </button>
      </form>
      <div>
        {records.map((curElem) => {
          const { id, fname, lname, contact, email, password } = curElem;
          return (
            <div key={id}>
              <p>{fname}</p>
              <p>{lname}</p>
              <p>{contact}</p>
              <p>{email}</p>
              <p>{password}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default UpdateProfile;
