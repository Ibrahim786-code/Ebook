import React, { useRef, useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  faCheck,
  faTimes,
  faInfoCircle
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import Login from './Login';

const USER_REGEX = /^[a-zA-Z][a-zA-Z0-9-_]{3,23}$/;
const PWD_REGX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%]).{8,24}$/;

const Register = (props) => {
  const [register, setRegister] = useState({
    fname: "",
    lname: "",
    contact: "",
    email: "",
    password: ""
  });
  const [error, setErrMsg] = useState("");
  const [records, setRecords] = useState([]);

  const handleInput = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    console.log(name, value);

    setRegister({ ...register, [name]: value });
  };
  const navigate = useNavigate();

  const backbutton = (e) => {
    e.preventDefault();
    navigate("/");
  };
  const gotologin = (e) => {
    e.preventDefault();
    navigate("/Login");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // if(records === 0){
    //   setErrMsg("Invalid email or password");
    // }
    // else{

    const newRecord = { ...register, id: new Date().getTime().toString() };
    console.log(records);
    setRecords([...records, newRecord]);
    console.log(records);

    setRegister({ fname: "", lname: "", contact: "", email: "", password: "" });
  };

  return (
    <div className="app">
      <h2>Register</h2>
      <form className="register-form" onSubmit={handleSubmit}>
        <label htmlFor="fname">First Name</label>
        <input
          value={register.fname}
          onChange={handleInput}
          // onChange={(e) => setFname(e.target.value)}
          autoComplete="off"
          name="fname"
          id="name"
          placeholder="First Name"
        />
        <br />
        <label htmlFor="lname">Last Name</label>
        <input
          value={register.lname}
          // onChange={(e) => setLname(e.target.value)}
          onChange={handleInput}
          autoComplete="off"
          name="lname"
          id="name"
          placeholder="Last Name"
        />
        <br />
        <label htmlFor="contact">Contact</label>
        <input
          type="text"
          value={register.contact}
          onChange={handleInput}
          // onChange={(e) => setContact(e.target.value)}
          autoComplete="off"
          name="contact"
          id="contact"
          placeholder="Contact"
        />
        <br />
        <label htmlFor="email">Email &nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input
          value={register.email}
          onChange={handleInput}
          // onChange={(e) => setEmail(e.target.value)}
          autoComplete="off"
          type="email"
          id="email"
          name="email"
          placeholder="abc@gmail"
        />
        <br />
        <label htmlFor="password">Password </label>
        <input
          value={register.password}
          onChange={handleInput}
          // onChange={(e) => setPass(e.target.value)}
          autoComplete="off"
          type="password"
          id="password"
          name="password"
          placeholder="******"
        />
        <br />
        {error && <p className="error">{error}</p>}
        <button type="submit" onClick={handleSubmit}>
          Register
        </button>
        &nbsp;&nbsp;&nbsp;
        <button type="cancel" onClick={backbutton}>
          Cancel
        </button>
      </form>
      <div>
        {records.map((curElem) => {
          const { id, fname, lname, contact, email, password } = curElem;
          return (
            <div key={id}>
              <p>{fname}</p>
              <p>{lname}</p>
              <p>{contact}</p>
              <p>{email}</p>
              <p>{password}</p>
            </div>
          );
        })}
      </div>
      <button className="link-btn" onClick={gotologin}>
        Already have an account? Login here.
      </button>
    </div>
  );
};

export default Register;

//  {/* {register ? (
//                 <p >You Are Registered Successfully</p>
//             ) :  (
//                 <p >You Are Not Registered</p>
//             )} */}

// const userRef = useRef();
// const errRef = useRef();

// const [fname, setFname] = useState("");
// const [validFname, setValidFname] = useState(false);
// const [fnameFocus, setFnameFocus] = useState(false);

// const [lname, setLname] = useState("");
// const [validLname, setValidlName] = useState(false);
// const [lnameFocus, setLnameFocus] = useState(false);

// const [contact, setContact] = useState("");
// const [validContact, setValidContact] = useState(false);
// const [contactFocus, setContactFocus] = useState(false);

// const [email, setEmail] = useState("");
// const [validEmail, setValidEmail] = useState(false);
// const [emailFocus, setEmailFocus] = useState(false);

// const [pass, setPass] = useState("");
// const [validPass, setValidPass] = useState(false);
// const [passFocus, setPassFocus] = useState(false);

// const [matchPass, setMatchPass] = useState("");
// const [validMatch, setValidMatch] = useState(false);
// const [matchFocus, setMatchFocus] = useState(false);

// const [ errMsg, setErrMsg ] = useState('');
// const [success, setSuccess ] = useState(false);

// useEffect ( () => {
//   // userRef.current.focus();

// }, [])

// setRegister(true);

//   const configuration = {
//     method: "post",
//     // url: "https://nodejs-mongodb-auth-app-learn.herokuapp.com/register",
//     data: {
//       fname,
//       lname,
//       contact,
//       email,
//       pass,
//     },
// };
// axios(configuration)
//           .then((result) => {
//               console.log(result);
//               setRegister(true);
//           })
//           .catch((error) => {
//               error= new Error;
//           })

// console.log(email);

// {/* <label htmlFor="password">Re-enter Password </label>
//   <input
//     value={register.matchPass}
//     onChange={ handleInput }
//     // onChange={(e) => setMatchPass(e.target.value)}
//     autoComplete="off"
//      type="password"
//     id="password"
//      name="password"
//      placeholder="******"
//   /> */}
