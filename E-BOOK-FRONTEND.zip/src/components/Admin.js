import React, { useState } from "react";
import { Link, BrowserRouter } from "react-router-dom";
import AddBook from "./AddBook";
import ViewBook from "./ViewBook";
import Logo from "./Assets/Logo.png";
import ebook3 from "./Assets/ebook3.jpg";
import ebook4 from "./Assets/ebook4.jpg";
import ebook2 from "./Assets/ebook2.jpg";
import ebook1 from "./Assets/ebook1.jpg";
import ebook from "./Assets/ebook.jpg";

export default function Admin() {
  return (
    <>
      <div className="admin">
        <nav>
          <div className="nav-logo-container">
            <Link to="/" className="navbar-logo">
              <img src={Logo} alt="" />
            </Link>
          </div>
          <h2>ADMIN</h2>
          <div className="navbar-links-container">
            <ul>
              <li>
                <Link className="navbar-links-container" to="/">
                  Home
                </Link>
              </li>
              <li>
                <Link className="navbar-links-container" to="/AddBook">
                  AddBook
                </Link>
              </li>
              <li>
                <Link className="navbar-links-container" to="/ViewBook">
                  ViewBook
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        <div className="admin-banner-container">
          <img src={ebook1} className="image" alt="" />
        </div>
        {/* <img src={ebook4} alt="" /> */}
        <div className="home-container">
          <h1 className="primary-heading">E BOOK MANAGEMENT</h1>
          <p className="primary-text">
            Books are my my favourite friends, and I consider my home library,
            with many thousand books, to be my greatest wealth.
            <br /> -A P J Abdul Kalam
          </p>
          {/* <div className="home-bannerImage-container">
            <img src={ebook4} alt="" />
          </div> */}
        </div>
      </div>
      {/* </div> */}
    </>
  );
}
