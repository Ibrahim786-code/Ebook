import { useNavigate } from "react-router-dom";
import React, { useState } from "react";
import { parseString } from "loader-utils";

export default function ViewBook() {
  const dummyData = [
    {
      BookId: 1,
      BookName: "Friction",
      InsertedDate: "2003/04/21",
      AuthorName: "Mathew"
    },
    {
      BookId: 2,
      BookName: "Earth",
      InsertedDate: "2005/01/12",
      AuthorName: "Joseph"
    },
    {
      BookId: 3,
      BookName: "Larry The Bird",
      InsertedDate: "1999/04/19",
      AuthorName: "Harry"
    }
  ];

  const [results, setResults] = useState([]);
  const [enteredBookName, setBookName] = useState("");

  const [value, setValue] = useState("");
  const [dataSource, setDataSource] = useState(dummyData);
  const [tableFilter, setTableFilter] = useState([]);

  const filterData = (e) => {
    if (e.target.value != "") {
      setValue(e.target.value);
      const filterTable = dataSource.filter((o) =>
        Object.keys(o).some((k) =>
          String(o[k]).toLowerCase().includes(e.target.value.toLowerCase())
        )
      );
      setTableFilter([...filterTable]);
    } else {
      setValue(e.target.value);
      setDataSource([...dataSource]);
    }
  };

  const navigate = useNavigate();

  const backbutton = (e) => {
    e.preventDefault();
    navigate("/Admin");
  };

  return (
    <>
      <div className="view-book">
        <div className="search-bar-container">
          <input
            type="text"
            class="form-control"
            placeholder="Search"
            aria-label="BookName"
            aria-describedby="basic-addon1"
            value={value}
            onChange={filterData}
          />
        </div>
        <div class="table">
          <br />
          <table>
            <thead>
              <tr>
                <th scope="col">Book Name</th>
                <th scope="col">Inserted Date</th>
                <th scope="col">Author Name</th>
              </tr>
            </thead>
            <tbody>
              {value.length > 0
                ? tableFilter.map((data) => {
                    return (
                      <tr key={data.BookName}>
                        <td>{data.BookName} </td>
                        <td>{data.InsertedDate} </td>
                        <td>{data.AuthorName} </td>
                      </tr>
                    );
                  })
                : dataSource.map((data) => {
                    return (
                      <tr key={data.BookName}>
                        <td>{data.BookName} </td>
                        <td>{data.InsertedDate} </td>
                        <td>{data.AuthorName} </td>
                      </tr>
                    );
                  })}
            </tbody>
          </table>
        </div>

        <div className="results-list">
          {results.map((result, id) => {
            return (
              <div
                className="search"
                key={id}
                onClick={(e) => alert(`You clicked on ${result.name}`)}
              >
                {result.name}
              </div>
            );
          })}
        </div>

        <div className="viewbookcancel">
          <button type="cancel" onClick={backbutton}>
            Cancel
          </button>
        </div>
      </div>
    </>
  );
}
