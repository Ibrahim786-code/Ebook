import React from "react";
import Navbar from "./Navbar";
import ebook4 from "./Assets/ebook4.jpg";
import ebook1 from "./Assets/ebook1.jpg";
export default function Home() {
  return (
    <>
      <Navbar />
      <div className="home-banner-container">
        <div className="home-bannerImage-container">
          <img src={ebook4} alt="" />
        </div>
        <div className="home-container">
          <h1 className="primary-heading">E BOOK MANAGEMENT</h1>
          <p className="primary-text">
            Books are my my favourite friends,
            <br /> and I consider my home library,
            <br />
            with many thousand books,
            <br /> to be my greatest wealth.
            <br />
            <br />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-A
            P J Abdul Kalam
          </p>
        </div>
      </div>
    </>
  );
}
