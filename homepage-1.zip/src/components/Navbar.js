import React, { useState } from "react";
import HomeIcon from "@mui/icons-material/Home";
import InfoIcon from "@mui/icons-material/Info";
import LoginIcon from "@mui/icons-material/Login";
import Logo from "./Assets/Logo.png";
import { HiOutlineBars3 } from "react-icons/hi2";
import Registration from "@mui/icons-material/HowToReg";
export default function Navbar() {
  
  const [openMenu, setOpenMenu] = useState(false);
  const menuOptions = [
    {
      text: "Home",
      icon: <HomeIcon />
    },
    
    {
      text: "Login",
      icon: <LoginIcon />
    },
    {
      text: "Registration",
      icon: <Registration />
    }
  ];

  return(
    <nav>
      <div className="logo">
        <img src={Logo} alt="" />
      </div>
      <div className="navbar-links-container">
        <a href="">Home</a>
        <a href="">Login</a>
        <a href="">Registration</a>
      </div>
       <div className="navbar-menu-container">
        <HiOutlineBars3 onClick={() => setOpenMenu(true)} />
      </div> 
      </nav>
      
  );

}