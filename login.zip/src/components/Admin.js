export default function Admin () {
  return (
    <>
    <h1>Welcome to admin page</h1>
    </>
  )
}