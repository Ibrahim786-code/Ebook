import { useNavigate } from "react-router-dom";
import React, { useState } from "react";

export default function Login(props) {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [error, setErrMsg] = useState("");
  const navigate = useNavigate();

  const backbutton = (e) => {
    e.preventDefault();
    navigate("/");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email === "admin@gmail.com" && pass === "admin@123") {
      console.log(" Admin Login Successfull");
      navigate("/admin");
    } else if (email === "user" && pass === "user") {
      console.log(" user Login Successfull");
      navigate("/User");
    } else {
      setErrMsg("Invalid email or password");
    }
    console.log(email);
  };

  return (
    <>
      <div className="app">
        <h2>Login</h2>
        <form className="login-form" onSubmit={handleSubmit}>
          <label htmlFor="email">Email &nbsp;&nbsp;&nbsp;&nbsp;</label>
          <input
            value={email}
            required
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            id="email"
            name="email"
            placeholder="abc@gmail"
          />

          <label htmlFor="password">Password </label>
          <input
            value={pass}
            required
            onChange={(e) => setPass(e.target.value)}
            type="password"
            id="password"
            name="password"
            placeholder="******"
          />
          {error && <p className="error">{error}</p>}
          <div class="button-container">
            <button type="submit" onClick={handleSubmit}>
              Log In
            </button>
            &nbsp;&nbsp;&nbsp;
            <button type="cancel" onClick={backbutton}>
              Cancel
            </button>
          </div>
        </form>

        <button
          className="link-btn"
          onClick={() => {
            "Register";
          }}
        >
          Don't have an account? Register here.
        </button>
      </div>
    </>
  );
}
