import React, { useState } from "react";
import { Link, BrowserRouter } from "react-router-dom";
import Logo from "./Assets/Logo.png";

export default function Navbar() {

  return (
    <>
      
      <nav className="navbar">
         <div className="nav-logo-container">
           <Link to="/" className="navbar-logo">
           <img src={Logo} alt="" />
             </Link>
         
       </div>
        <div className="navbar-links-container">
      
        <ul >
          <li >
            <Link className="navbar-links-container" to="/">
              Home
            </Link>
          </li>
          <li >
            <Link className="navbar-links-container" to="/Login">
              Login
            </Link>
          </li>
          <li >
            <Link className="navbar-links-container" to="/">
              Registration
            </Link>
          </li>
        </ul>
        </div>
      </nav>
    </>
   
  );
}
