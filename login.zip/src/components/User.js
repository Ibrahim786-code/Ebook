export default function User() {
  return (
    <>
      <h1>Welcome to User page</h1>
    </>
  );
}
