import React, { useState } from "react";
import "./App.css";
import Home from "./components/Home";
import Admin from "./components/Admin";
import User from "./components/User";
import Login from "./components/Login";
import Register from "./components/Register";
import { BrowserRouter, Route, Router, Link, Routes } from "react-router-dom";

export default function App() {
  const [currentForm, setCurrentForm] = useState("Login");

  const toggleForm = (formName) => {
    setCurrentForm(formName);
  };

  return (
    <>
      {/* <div className="App">
        {currentForm === "Login" ? (
          <Login onFormSwitch={toggleForm} />
        ) : (
          <Register onFormSwitch={toggleForm} />
        )}
      </div> */}
     
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/Admin" element={<Admin />} />
        <Route path="/User" element={<User />} />
        <Route path="/" element={<Register />} />
      </Routes>

      
    </>
  );
}
